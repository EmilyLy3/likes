// First user Neil's count
var count1 = 9;
var countElement1 = document.querySelector("#counter1");

function increase1() {
    count1++;
    countElement1.innerHTML = count1 + " like(s)";
};

// Second user Nichole's count
var count2 = 12;
var countElement2 = document.querySelector("#counter2");

function increase2() {
    count2++;
    countElement2.innerHTML = count2 + " like(s)";
};

// Third user Jim's count
var count3 = 9;
var countElement3 = document.querySelector("#counter3");

function increase3() {
    count3++;
    countElement3.innerHTML = count3 + " like(s)";
};